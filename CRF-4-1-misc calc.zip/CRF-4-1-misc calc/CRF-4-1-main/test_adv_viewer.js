const { chromium } = require('playwright');
const path = require('path');

(async () => {
  const browser = await chromium.launch({ args: ['--no-sandbox', '--allow-file-access-from-files'] });
  const page = await browser.newPage();

  page.on('console', msg => console.log('BROWSER CONSOLE:', msg.text()));
  page.on('pageerror', err => console.log('BROWSER ERROR:', err.message));

  await page.goto(`file://${path.resolve(__dirname, 'viewer/index.html')}`);

  await page.waitForTimeout(1000);

  const advTabBtn = page.locator('button.tab-btn:has-text("Advanced GLB Viewer")');
  await advTabBtn.click();
  console.log("Navigated to Advanced GLB Viewer Tab");
  await page.waitForTimeout(1000);

  // Upload the file
  await page.locator('#adv-file-input').set_input_files('/home/jules/verification/STEAM_SISO.pcf')
  // We don't have a PCF parser on this tab, it only accepts GLB. Let's create a dummy GLB or use state.
  console.log("Advanced tab instantiated.");

  await browser.close();
})();
