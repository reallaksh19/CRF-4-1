import { getLinelistService } from '../../core/linelist-store.js';
import { computeOperatingConditions } from '../../utils/max-finder.js';
import { state } from '../../core/state.js';
import { getCaesarMatchAttribute } from '../../core/settings.js';

function createProvenance(field, value, unit, sourceType, sourcePath, matchedLine, format, fallbackReason, confidence) {
    return {
        field, value, unit, sourceType, sourcePath, matchedLine, sourceFormat: format, fallbackReason, confidence
    };
}

export function resolveShellIndentInputs(basis, manualInputs) {
    const { element, node, force } = basis;
    const format = state.parsed?.format || 'UNKNOWN';
    const llService = getLinelistService();
    const globalOps = computeOperatingConditions(state.parsed) || {};

    const resolved = {};
    const assumptions = [];
    const resolutionLog = {};

    let lineRef = manualInputs.lineRef;
    let matchedLine = null;
    const matchAttr = getCaesarMatchAttribute();

    if (element && element[matchAttr]) {
        lineRef = element[matchAttr];
    }

    const llAttrs = lineRef ? llService.getSmartAttributes(lineRef) : null;
    if (llAttrs && llAttrs.Found) {
        matchedLine = lineRef;
    }

    // Geometry Fields (OD, wall)
    if (element && element.od > 0) {
        resolved.od = element.od;
        resolutionLog.od = createProvenance("od", element.od, "mm", "parsed", `element[${element.id || element.SEQ_NO}]`, matchedLine, format, "", "high");
    } else {
        resolved.od = manualInputs.od;
        resolutionLog.od = createProvenance("od", manualInputs.od, "mm", "manual", "user input", matchedLine, format, "parsed od missing", "medium");
    }

    if (element && element.wall > 0) {
        resolved.wall = element.wall;
        resolutionLog.wall = createProvenance("wall", element.wall, "mm", "parsed", `element[${element.id || element.SEQ_NO}]`, matchedLine, format, "", "high");
    } else {
        resolved.wall = manualInputs.wall;
        resolutionLog.wall = createProvenance("wall", manualInputs.wall, "mm", "manual", "user input", matchedLine, format, "parsed wall missing", "medium");
    }

    resolved.id = resolved.od - (2 * resolved.wall);

    // Effective Wall
    resolved.effWall = manualInputs.effWall;
    if (resolved.effWall <= 0 || !resolved.effWall) {
        resolved.effWall = resolved.wall;
        resolutionLog.effWall = createProvenance("effWall", resolved.effWall, "mm", "assumed", "nominal wall", matchedLine, format, "no manual effWall", "medium");
        assumptions.push("effectiveWall assumed to be nominal wall");
    } else {
        resolutionLog.effWall = createProvenance("effWall", resolved.effWall, "mm", "manual", "user input", matchedLine, format, "", "high");
    }

    // Process Fields (T1, P1)
    if (element && element.T1 !== undefined) {
        resolved.T1 = element.T1;
        resolutionLog.T1 = createProvenance("T1", element.T1, "C", "parsed", `element[${element.id || element.SEQ_NO}]`, matchedLine, format, "", "high");
    } else if (globalOps.T1 !== undefined) {
        resolved.T1 = globalOps.T1;
        resolutionLog.T1 = createProvenance("T1", globalOps.T1, "C", "parsed", `global`, matchedLine, format, "element T1 missing", "medium");
    } else if (llAttrs && (llAttrs.DesignTemp || llAttrs.OperatingTemp)) {
        resolved.T1 = parseFloat(llAttrs.DesignTemp || llAttrs.OperatingTemp);
        resolutionLog.T1 = createProvenance("T1", resolved.T1, "C", "linelist", `linelist[${matchedLine}]`, matchedLine, format, "parsed T1 missing", "medium");
    } else {
        resolved.T1 = manualInputs.T1 || 25;
        resolutionLog.T1 = createProvenance("T1", resolved.T1, "C", "manual", "user input", matchedLine, format, "no parsed/linelist T1", "low");
    }

    if (element && element.P1 !== undefined) {
        resolved.P1 = element.P1;
        resolutionLog.P1 = createProvenance("P1", element.P1, "MPa", "parsed", `element[${element.id || element.SEQ_NO}]`, matchedLine, format, "", "high");
    } else if (globalOps.P1 !== undefined) {
        resolved.P1 = globalOps.P1;
        resolutionLog.P1 = createProvenance("P1", globalOps.P1, "MPa", "parsed", `global`, matchedLine, format, "element P1 missing", "medium");
    } else if (llAttrs && (llAttrs.DesignPressure || llAttrs.OperatingPressure)) {
        resolved.P1 = parseFloat(llAttrs.DesignPressure || llAttrs.OperatingPressure);
        resolutionLog.P1 = createProvenance("P1", resolved.P1, "MPa", "linelist", `linelist[${matchedLine}]`, matchedLine, format, "parsed P1 missing", "medium");
    } else {
        resolved.P1 = manualInputs.P1 || 0;
        resolutionLog.P1 = createProvenance("P1", resolved.P1, "MPa", "manual", "user input", matchedLine, format, "no parsed/linelist P1", "low");
    }

    // Force Fields
    if (force) {
        resolved.f_normal = Math.abs(force.fy || force.fx || force.fz || 0); // simplistic extraction of the dominant parsed force
        if (resolved.f_normal === 0) resolved.f_normal = Math.max(Math.abs(force.fx||0), Math.abs(force.fy||0), Math.abs(force.fz||0));

        resolutionLog.f_normal = createProvenance("f_normal", resolved.f_normal, "N", "parsed", `forces[${force.node}]`, matchedLine, format, "", "high");
    } else {
        resolved.f_normal = manualInputs.f_normal || 0;
        resolutionLog.f_normal = createProvenance("f_normal", manualInputs.f_normal, "N", "manual", "user input", matchedLine, format, "parsed force missing", "medium");
        assumptions.push("manual force used because parsed force unavailable");
    }

    // Assumptions & Manual Geometry (Contact dimensions, footprint, etc)
    resolved.footprintType = manualInputs.footprintType || 'narrow'; // narrow | rectangular | strip
    resolutionLog.footprintType = createProvenance("footprintType", resolved.footprintType, "", "manual", "user input", matchedLine, format, "", "high");

    resolved.contactWidth = manualInputs.contactWidth || 0;
    resolutionLog.contactWidth = createProvenance("contactWidth", resolved.contactWidth, "mm", "manual", "user input", matchedLine, format, "", "high");

    resolved.contactLength = manualInputs.contactLength || 0;
    resolutionLog.contactLength = createProvenance("contactLength", resolved.contactLength, "mm", "manual", "user input", matchedLine, format, "", "high");

    resolved.kFactor = manualInputs.kFactor || 1.8; // Default concentration factor
    resolutionLog.kFactor = createProvenance("kFactor", resolved.kFactor, "", "manual", "user input", matchedLine, format, "", "medium");
    if (!manualInputs.kFactor) assumptions.push("concentration factor K defaulted to 1.8");

    resolved.allowable = manualInputs.allowable || 0;
    resolutionLog.allowable = createProvenance("allowable", resolved.allowable, "MPa", "manual", "user input", matchedLine, format, "", "medium");

    resolved.ignorePads = manualInputs.ignorePads !== false;
    if (resolved.ignorePads) assumptions.push("pad/stiffener effects ignored");

    return {
        basis: {
            lineRef,
            parsedFormat: format,
            elementIndex: element ? element.id || element.SEQ_NO : null,
            nodeId: node || (force ? force.node : null)
        },
        resolved,
        resolutionLog,
        assumptions
    };
}
