export const ShellIndentationCalc = {
  id: 'mc-shellindent',
  name: 'Pipe Shell Indentation',
  method: 'Local Shell Stress (Screening)',
  normalize: (raw, mode, steps) => {
    steps.push(`Normalize inputs. Note: Inputs are pre-resolved via shell-indent-resolver.`);
    return raw; // Inputs come pre-resolved from resolver
  },
  run: (envelope) => {
    const resPayload = envelope.normalizedInputs;

    // We attach the resolved bundle to the envelope for UI consumption
    envelope.inputResolution = resPayload.resolutionLog;
    envelope.sourceSnapshot = resPayload.basis;
    envelope.assumptions = resPayload.assumptions;

    const {
        od, wall, effWall, f_normal, footprintType,
        contactWidth, contactLength, kFactor, allowable
    } = resPayload.resolved;

    // Hard validations
    if (od <= 0) throw new Error("OD must be > 0");
    if (wall <= 0) throw new Error("Wall thickness must be > 0");
    if (f_normal <= 0) throw new Error("A normal load must be entered to calculate bearing stress");
    if (contactWidth <= 0) throw new Error("Contact width must be > 0");

    let L_eff = contactLength;
    if (footprintType === 'rectangular' && L_eff <= 0) {
        throw new Error("Contact length must be > 0 for a rectangular patch");
    } else if (footprintType === 'narrow' || footprintType === 'strip') {
        // Narrow footprint, assume a square patch if L is 0, or just use width
        if (L_eff <= 0) L_eff = contactWidth;
    }

    const id = od - (2 * wall);
    envelope.steps.push(`1. Calculate Internal Diameter: ID = OD - 2t = ${od} - 2*${wall} = ${id.toFixed(3)}`);

    const a_contact = contactWidth * L_eff;
    envelope.steps.push(`2. Calculate Contact Area: A_contact = b x L = ${contactWidth} x ${L_eff} = ${a_contact.toFixed(2)}`);

    const sigma_bearing = f_normal / a_contact;
    envelope.steps.push(`3. Calculate Bearing Stress: sigma_bearing = F_normal / A_contact = ${f_normal} / ${a_contact.toFixed(2)} = ${sigma_bearing.toFixed(3)}`);

    const sigma_local = (kFactor * f_normal) / (contactWidth * effWall);
    envelope.steps.push(`4. Calculate Local Screening Stress: sigma_local = K * F_normal / (b * t_eff) = ${kFactor} * ${f_normal} / (${contactWidth} * ${effWall}) = ${sigma_local.toFixed(3)}`);

    let ur = 0;
    let pass = true;

    if (allowable > 0) {
        ur = sigma_local / allowable;
        pass = ur <= 1.0;
        envelope.steps.push(`5. Calculate Utilization Ratio: UR = sigma_local / sigma_allowable = ${sigma_local.toFixed(3)} / ${allowable} = ${ur.toFixed(3)}`);
    } else {
        envelope.steps.push(`5. No allowable entered. Utilization ratio skipped.`);
    }

    envelope.intermediateValues = { id, a_contact };
    envelope.outputs = {
        sigma_bearing,
        sigma_local,
        ur
    };

    envelope.pass = pass;

    envelope.benchmark = {
        source: "Bare Pipe - Local Loading.xls",
        caseId: "PENDING_SOURCE_EXTRACTION",
        expected: "N/A",
        actual: sigma_local,
        status: "PENDING"
    };

    envelope.warnings.push("This is a screening representation, not a full shell solution or code-certified exact solver.");
    if (resPayload.assumptions.length > 0) {
        resPayload.assumptions.forEach(a => envelope.warnings.push(a));
    }
  }
};
