import { createSvgShell, drawDimension, svgDefs } from './svg-shell.js';

export function generateShellIndentSvg(resPayload) {
  if (!resPayload) return `<span style="color:#888;">[Resolver Data Missing]</span>`;

  const { od, wall, f_normal, contactWidth, contactLength, footprintType } = resPayload.resolved;

  const provOD = resPayload.resolutionLog.od.sourceType;
  const provF = resPayload.resolutionLog.f_normal.sourceType;
  const provAllow = resPayload.resolutionLog.allowable.sourceType;

  const isRect = footprintType === 'rectangular';
  const isStrip = footprintType === 'strip';
  const isNarrow = footprintType === 'narrow';

  // Proportional scaling base
  const baseScale = 100 / (od || 100);
  const visualR = (od / 2) * baseScale;
  const visualInnerR = ((od - 2*wall) / 2) * baseScale;

  const cx = 175;
  const cy = 150;

  // Contact representations
  let contactSvg = '';

  if (isStrip) {
      contactSvg = `<rect x="${cx - visualR - 10}" y="${cy - visualR - 10}" width="${(visualR + 10)*2}" height="20" fill="rgba(255,0,0,0.3)" stroke="red"/>`;
      contactSvg += `<text x="${cx}" y="${cy - visualR - 15}" fill="red" text-anchor="middle" font-size="10">Line/Strip Load</text>`;
  } else if (isRect) {
      // Representing a pad/plate
      contactSvg = `<rect x="${cx - (contactWidth/2)}" y="${cy - visualR - 10}" width="${contactWidth}" height="10" fill="#ccf" stroke="#333"/>`;
      contactSvg += `<rect x="${cx - (contactWidth/2)}" y="${cy - visualR - 5}" width="${contactWidth}" height="10" fill="rgba(255,0,0,0.3)"/>`;
      contactSvg += `<text x="${cx}" y="${cy - visualR - 15}" fill="red" text-anchor="middle" font-size="10">b = ${contactWidth}, L = ${contactLength}</text>`;
  } else {
      // Narrow/Point
      contactSvg = `<circle cx="${cx}" cy="${cy - visualR}" r="5" fill="red"/>`;
      contactSvg += `<text x="${cx + 10}" y="${cy - visualR - 5}" fill="red" font-size="10">Narrow b = ${contactWidth}</text>`;
  }

  const svg = `
    ${createSvgShell("0 0 350 350")}
    ${svgDefs}

    <text x="${cx}" y="20" text-anchor="middle" font-weight="bold" font-size="14">Pipe Shell Contact</text>
    <text x="${cx}" y="35" text-anchor="middle" fill="#666" font-size="10">Mode: ${footprintType}</text>

    <!-- Cross Section -->
    <circle cx="${cx}" cy="${cy}" r="${visualR}" fill="none" stroke="#333" stroke-width="3"/>
    <circle cx="${cx}" cy="${cy}" r="${visualInnerR}" fill="none" stroke="#333" stroke-width="1" stroke-dasharray="5,5"/>

    ${contactSvg}

    <!-- Load Vector -->
    <line x1="${cx}" y1="${cy - visualR - 60}" x2="${cx}" y2="${cy - visualR - 15}" stroke="red" stroke-width="3" marker-end="url(#arrow)"/>
    <text x="${cx + 10}" y="${cy - visualR - 40}" fill="red" font-weight="bold">F_n = ${f_normal} N</text>

    <!-- Dimensions -->
    ${drawDimension(cx - visualR, cy, cx + visualR, cy, `OD = ${od}`, -visualR - 40)}
    ${drawDimension(cx, cy - visualR, cx, cy - visualInnerR, `t = ${wall}`, visualR + 30)}

    <!-- Provenance Footer -->
    <rect x="0" y="300" width="350" height="50" fill="#f0f0f0" />
    <text x="10" y="320" font-size="10" fill="#555">Line: ${resPayload.basis.lineRef || 'Manual'}</text>
    <text x="10" y="335" font-size="10" fill="#555">Src Geom: ${provOD} | Src Load: ${provF} | Src Allow: ${provAllow}</text>
    </svg>
  `;

  return svg;
}
