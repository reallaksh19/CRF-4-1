export function createToolbar(container, cameraController) {
  container.innerHTML = `
      <div style="display: flex; gap: 8px; align-items: center;">
          <label style="font-size: 11px; margin-right: 5px;">Color By:</label>
          <select id="adv-color-prop" style="font-size: 11px; padding: 2px; max-width: 120px;" disabled>
              <option value="default">Default</option>
          </select>
          <button class="btn-icon" id="adv-view-iso" title="Isometric View" style="padding: 2px 6px; margin-left: 10px; font-size: 11px;">ISO</button>
          <button class="btn-icon" id="adv-view-top" title="Top View" style="padding: 2px 6px; font-size: 11px;">TOP</button>
          <button class="btn-icon" id="adv-view-front" title="Front View" style="padding: 2px 6px; font-size: 11px;">FRONT</button>
          <button class="btn-icon" id="adv-view-side" title="Side View" style="padding: 2px 6px; font-size: 11px;">SIDE</button>
          <button class="btn-icon" id="adv-view-fit" title="Fit Scene" style="padding: 2px 6px; font-size: 11px; margin-left: 10px;">FIT ALL</button>

          <button class="btn-icon" id="adv-section-btn" title="Toggle Section Box" style="padding: 2px 6px; margin-left: 10px; font-size: 11px; border: 1px solid transparent;">CLIP OFF</button>
      </div>
      <!-- Legend Panel -->
      <div id="adv-legend-panel" style="position: absolute; bottom: 20px; left: 20px; background: rgba(30, 45, 66, 0.9); color: white; padding: 10px; border-radius: 4px; font-size: 11px; display: none; max-height: 200px; overflow-y: auto; z-index: 10;">
          <strong>Legend</strong>
          <div id="adv-legend-content" style="margin-top: 5px;"></div>
      </div>
  `;

  const colorSelect = container.querySelector('#adv-color-prop');
  let heatmapHandler = null;
  let sectionHandler = null;

  const sectionBtn = container.querySelector('#adv-section-btn');
  let sectionOn = false;
  sectionBtn.addEventListener('click', () => {
      sectionOn = !sectionOn;
      if (sectionOn) {
          sectionBtn.style.border = '1px solid #4f4';
          sectionBtn.style.color = '#4f4';
          sectionBtn.textContent = 'CLIP ON';
      } else {
          sectionBtn.style.border = '1px solid transparent';
          sectionBtn.style.color = 'inherit';
          sectionBtn.textContent = 'CLIP OFF';
      }
      if (sectionHandler) sectionHandler(sectionOn);
  });

  colorSelect.addEventListener('change', (e) => {
      if (heatmapHandler) heatmapHandler(e.target.value);
  });

  container.querySelector('#adv-view-iso').addEventListener('click', () => cameraController.setPresetView('ISO'));
  container.querySelector('#adv-view-top').addEventListener('click', () => cameraController.setPresetView('TOP'));
  container.querySelector('#adv-view-front').addEventListener('click', () => cameraController.setPresetView('FRONT'));
  container.querySelector('#adv-view-side').addEventListener('click', () => cameraController.setPresetView('SIDE'));

  let fitHandler = null;
  container.querySelector('#adv-view-fit').addEventListener('click', () => {
    if (fitHandler) fitHandler();
  });

  const legendPanel = container.querySelector('#adv-legend-panel');
  const legendContent = container.querySelector('#adv-legend-content');

  return {
    setFitHandler: (fn) => { fitHandler = fn; },
    setHeatmapHandler: (fn) => { heatmapHandler = fn; },
    setSectionHandler: (fn) => { sectionHandler = fn; },
    setProperties: (props) => {
        let html = `<option value="default">Default</option>`;
        props.forEach(p => {
            html += `<option value="${p}">${p}</option>`;
        });
        colorSelect.innerHTML = html;
        colorSelect.disabled = false;
    },
    updateLegend: (legendHtml) => {
        if (!legendHtml) {
            legendPanel.style.display = 'none';
        } else {
            legendContent.innerHTML = legendHtml;
            legendPanel.style.display = 'block';
        }
    }
  };
}
