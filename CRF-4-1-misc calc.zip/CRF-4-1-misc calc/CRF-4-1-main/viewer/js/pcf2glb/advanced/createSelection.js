import * as THREE from 'three';

export function resolveInspectableObject(obj) {
  let cur = obj;
  while (cur) {
    if (cur.userData?.pcfId) return cur;
    cur = cur.parent;
  }
  return obj;
}

export function createSelection(camera, scene, domElement) {
  const raycaster = new THREE.Raycaster();
  const mouse = new THREE.Vector2();

  let selectionCallback = null;

  const onClick = (e) => {
    const rect = domElement.getBoundingClientRect();
    mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    raycaster.setFromCamera(mouse, camera);
    const intersects = raycaster.intersectObjects(scene.children, true);

    let clickedObject = null;
    for (const intersect of intersects) {
        // Skip helpers (assuming helpers don't have userData.pcfId and are not Meshes we care about)
        if (intersect.object.type === 'Mesh') {
            clickedObject = resolveInspectableObject(intersect.object);
            if (clickedObject && clickedObject.userData && clickedObject.userData.pcfId) {
                break;
            } else {
                clickedObject = null;
            }
        }
    }

    if (selectionCallback) {
        selectionCallback(clickedObject);
    }
  };

  domElement.addEventListener('pointerdown', onClick);

  return {
    onSelect: (fn) => { selectionCallback = fn; },
    dispose: () => {
        domElement.removeEventListener('pointerdown', onClick);
    }
  };
}
