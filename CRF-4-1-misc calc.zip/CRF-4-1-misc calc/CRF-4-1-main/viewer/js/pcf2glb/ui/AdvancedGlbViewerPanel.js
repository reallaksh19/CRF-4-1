import { createViewerApp } from '../advanced/createViewerApp.js';
import { loadMockPcfToGlbUrl, loadMockGlbUrl } from '../pro-editor/core/mockLoader.js';

export function renderAdvancedGlbViewerPanel(container) {
  container.innerHTML = `
    <div style="display: flex; height: calc(100vh - 120px);">
      <!-- Left Panel: Controls -->
      <div style="width: 300px; padding: 20px; background: #f0f4f8; border-right: 1px solid #ccc; display: flex; flex-direction: column;">
        <h3>Advanced GLB Viewer</h3>
        <p style="margin-bottom: 20px; font-size: 12px; color: #666;">Strict Vanilla JS professional engineering viewer.</p>

        <input type="file" id="adv-file-input" accept=".glb,.gltf" style="margin-bottom: 10px;">
        <button id="btn-adv-load" class="btn-primary" style="margin-bottom: 20px;" disabled>Load File</button>

        <hr style="margin: 20px 0;">
        <h4 style="margin-top:0;">Quick Mocks</h4>
        <div style="display: flex; gap: 10px;">
            <button id="btn-adv-mock-pcf" class="btn-secondary" title="Load Mock PCF (30+ elements)">📦 PCF</button>
            <button id="btn-adv-mock-glb" class="btn-secondary" title="Load Mock GLB">📦 GLB</button>
        </div>
      </div>

      <!-- Right Panel: Preview -->
      <div style="flex: 1; display: flex; flex-direction: column; position: relative;">
        <div style="background: #1e2d42; color: #fff; padding: 10px; display: flex; justify-content: space-between; align-items: center;">
          <span>Advanced 3D Viewer</span>
          <div id="adv-toolbar"></div>
        </div>
        <div id="adv-preview-container" style="flex: 1; background: #222; position: relative;"></div>

        <!-- Debug Panel Toggle -->
        <button id="btn-adv-debug-toggle" style="position: absolute; right: 16px; bottom: 16px; z-index: 10; padding: 8px 12px; border-radius: 8px; border: 0; background: #223344; color: #fff; cursor: pointer;">Debug</button>
        <div id="adv-debug-panel" style="position: absolute; right: 16px; bottom: 16px; width: 420px; max-height: 70vh; overflow: hidden; z-index: 20; border-radius: 12px; border: 1px solid rgba(255,255,255,0.08); background: #11151b; color: #ddd; box-shadow: 0 10px 40px rgba(0,0,0,0.35); display: none;">
             <div style="display: flex; justify-content: space-between; padding: 12px; border-bottom: 1px solid rgba(255,255,255,0.08);">
                 <strong>Debug</strong>
                 <button id="btn-adv-debug-close" style="background:none;border:none;color:white;cursor:pointer;">Close</button>
             </div>
             <div style="padding: 12px; max-height: 52vh; overflow: auto; font-family: monospace; font-size: 11px;">
                 Active Logs:<br>
                 <div id="adv-debug-logs"></div>
             </div>
        </div>

        <div id="adv-property-panel" style="position: absolute; top: 50px; right: 20px; width: 300px; background: rgba(30, 45, 66, 0.9); color: white; padding: 15px; border-radius: 4px; box-shadow: 0 4px 6px rgba(0,0,0,0.3); display: none; z-index: 10;">
            <div style="display: flex; justify-content: space-between; border-bottom: 1px solid #555; padding-bottom: 5px; margin-bottom: 10px;">
                <strong style="font-size: 14px;">Component Properties</strong>
                <button id="btn-adv-close-props" style="background: none; border: none; color: white; cursor: pointer; font-weight: bold;">✕</button>
            </div>
            <div id="adv-property-content" style="max-height: 400px; overflow-y: auto; font-size: 12px; font-family: monospace;"></div>
        </div>
      </div>
    </div>
  `;

  const fileInput = container.querySelector('#adv-file-input');
  const btnLoad = container.querySelector('#btn-adv-load');
  const previewContainer = container.querySelector('#adv-preview-container');
  const toolbarContainer = container.querySelector('#adv-toolbar');
  const propPanel = container.querySelector('#adv-property-panel');
  const propContent = container.querySelector('#adv-property-content');
  const btnCloseProps = container.querySelector('#btn-adv-close-props');

  const debugToggle = container.querySelector('#btn-adv-debug-toggle');
  const debugPanel = container.querySelector('#adv-debug-panel');
  const debugClose = container.querySelector('#btn-adv-debug-close');
  const debugLogs = container.querySelector('#adv-debug-logs');

  debugToggle.addEventListener('click', () => {
      debugPanel.style.display = 'block';
      debugToggle.style.display = 'none';
  });
  debugClose.addEventListener('click', () => {
      debugPanel.style.display = 'none';
      debugToggle.style.display = 'block';
  });

  let currentFile = null;

  fileInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
      currentFile = e.target.files[0];
      btnLoad.disabled = false;
    } else {
      currentFile = null;
      btnLoad.disabled = true;
    }
  });

  const viewerApp = createViewerApp(previewContainer, toolbarContainer, propPanel, propContent, debugLogs);

  btnLoad.addEventListener('click', async () => {
      if (!currentFile) return;
      const url = URL.createObjectURL(currentFile);
      await viewerApp.loadGLB(url);
  });

  container.querySelector('#btn-adv-mock-pcf').addEventListener('click', async (e) => {
      e.target.disabled = true;
      e.target.textContent = 'Loading...';
      try {
          const url = await loadMockPcfToGlbUrl();
          await viewerApp.loadGLB(url);
      } catch (err) {
          console.error(err);
      } finally {
          e.target.disabled = false;
          e.target.textContent = '📦 PCF';
      }
  });

  container.querySelector('#btn-adv-mock-glb').addEventListener('click', async (e) => {
      e.target.disabled = true;
      e.target.textContent = 'Loading...';
      try {
          const url = await loadMockGlbUrl();
          await viewerApp.loadGLB(url);
      } catch (err) {
          console.error(err);
      } finally {
          e.target.disabled = false;
          e.target.textContent = '📦 GLB';
      }
  });

  btnCloseProps.addEventListener('click', () => {
      propPanel.style.display = 'none';
  });

}
