#!/bin/bash
ZIP_NAME="CRF4_1_ProGLB_Editor.zip"
zip -r "$ZIP_NAME" viewer/
