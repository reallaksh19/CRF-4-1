class Vector3 {
  constructor(x = 0, y = 0, z = 0) { this.x = x; this.y = y; this.z = z; }
  set(x, y, z) { this.x = x; this.y = y; this.z = z; return this; }
  clone() { return new Vector3(this.x, this.y, this.z); }
  sub(v) { this.x -= v.x; this.y -= v.y; this.z -= v.z; return this; }
  add(v) { this.x += v.x; this.y += v.y; this.z += v.z; return this; }
  multiplyScalar(s) { this.x *= s; this.y *= s; this.z *= s; return this; }
  length() { return Math.sqrt(this.x*this.x + this.y*this.y + this.z*this.z); }
}
class Box3 {
  constructor(min = new Vector3(+Infinity, +Infinity, +Infinity), max = new Vector3(-Infinity, -Infinity, -Infinity)) { this.min = min; this.max = max; }
  setFromObject(object) {
    if (object && object.geometry && object.geometry.boundingBox) {
      this.min = object.geometry.boundingBox.min.clone();
      this.max = object.geometry.boundingBox.max.clone();
      return this;
    }
    if (object && object.geometry && object.geometry.parameters) {
      const p = object.geometry.parameters;
      const hw = (p.width || 0) / 2;
      const hh = (p.height || 0) / 2;
      const hd = (p.depth || 0) / 2;
      this.min = new Vector3(-hw, -hh, -hd);
      this.max = new Vector3(hw, hh, hd);
    }
    return this;
  }
  getSize(target) { target.x = this.max.x - this.min.x; target.y = this.max.y - this.min.y; target.z = this.max.z - this.min.z; return target; }
}
class BoxGeometry {
  constructor(width = 1, height = 1, depth = 1) {
    this.parameters = { width, height, depth };
    const hw = width/2, hh = height/2, hd = depth/2;
    this.boundingBox = new Box3(new Vector3(-hw,-hh,-hd), new Vector3(hw,hh,hd));
  }
}
class Mesh { constructor(geometry, material) { this.geometry = geometry; this.material = material; } }
class MeshBasicMaterial { constructor(params = {}) { this.params = params; } }
module.exports = { Vector3, Box3, BoxGeometry, Mesh, MeshBasicMaterial };
