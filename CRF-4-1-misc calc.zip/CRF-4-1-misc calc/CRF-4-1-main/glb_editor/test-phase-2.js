const { computeBoundingMeasurement } = require('../viewer/js/pcf2glb/pro-editor/core/measureUtils.js');

let THREE;
try {
  THREE = require('three');
} catch (err) {
  THREE = require('./three-stub.js');
}

function approxEqual(a, b, epsilon = 1e-6) {
  return Math.abs(a - b) < epsilon;
}

function testMeasureBox() {
  const boxGeom = new THREE.BoxGeometry(2, 4, 6);
  const mesh = new THREE.Mesh(boxGeom, new THREE.MeshBasicMaterial());
  const stats = computeBoundingMeasurement(mesh);
  if (!approxEqual(stats.width, 2) || !approxEqual(stats.height, 4) || !approxEqual(stats.depth, 6)) {
    throw new Error(`Box measurement incorrect: ${stats.width},${stats.height},${stats.depth}`);
  }
  const expectedDiag = Math.sqrt(2 * 2 + 4 * 4 + 6 * 6);
  if (!approxEqual(stats.diagonal, expectedDiag)) {
    throw new Error(`Box diagonal incorrect: ${stats.diagonal} vs ${expectedDiag}`);
  }
}

try {
  testMeasureBox();
  console.log('Phase 2 smoke tests passed');
} catch (err) {
  console.error(err);
  process.exit(1);
}
