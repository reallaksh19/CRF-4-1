const { loadDataTable, getRow, setRowField } = require('../viewer/js/pcf2glb/pro-editor/core/dataStore.js');
const { createCommandStack } = require('../viewer/js/pcf2glb/pro-editor/core/commandStack.js');

function testDataStore() {
  loadDataTable([
    { id: 'A', foo: 1 },
    { id: 'B', bar: 'x' },
  ]);
  if (!getRow('A') || getRow('A').foo !== 1) throw new Error('DataStore getRow failed');
  setRowField('A', 'foo', 2);
  if (getRow('A').foo !== 2) throw new Error('DataStore setRowField failed');
  setRowField('C', 'baz', 42);
  if (!getRow('C') || getRow('C').baz !== 42) throw new Error('DataStore setRowField new row failed');
}

function testCommandStack() {
  const cs = createCommandStack();
  let value = 0;
  const cmd = {
    do() { value = 10; },
    undo() { value = 0; },
  };
  cs.exec(cmd);
  if (value !== 10) throw new Error('CommandStack exec failed');
  cs.undo();
  if (value !== 0) throw new Error('CommandStack undo failed');
  cs.redo();
  if (value !== 10) throw new Error('CommandStack redo failed');
}

try {
  testDataStore();
  testCommandStack();
  console.log('Phase 1 smoke tests passed');
} catch (err) {
  console.error(err);
  process.exit(1);
}
