const { loadDataTable, getRow, setRowField } = require('./viewer/js/pcf2glb/pro2-editor/core/PRO2EDITOR_dataStore.js');
const { createCommandStack } = require('./viewer/js/pcf2glb/pro2-editor/core/PRO2EDITOR_commandStack.js');
const { computeBoundingMeasurement } = require('./viewer/js/pcf2glb/pro2-editor/core/PRO2EDITOR_measureUtils.js');

let THREE;
try { THREE = require('three'); }
catch (err) { THREE = require('./three-stub.js'); }

function approxEqual(a, b, epsilon = 1e-6) { return Math.abs(a - b) < epsilon; }

function testDataStore() {
  loadDataTable([{ id: 'P100', diameter: 6, type: 'PIPE' }, { id: 'F200', rating: '150', type: 'FLANGE' }]);
  if (!getRow('P100') || getRow('P100').diameter !== 6) throw new Error('PRO2EDITOR data store failed to load rows');
  setRowField('P100', 'diameter', 8);
  if (getRow('P100').diameter !== 8) throw new Error('PRO2EDITOR data store failed to update existing row');
  setRowField('V300', 'type', 'VALVE');
  if (!getRow('V300') || getRow('V300').type !== 'VALVE') throw new Error('PRO2EDITOR data store failed to create new row');
}

function testCommandStack() {
  const stack = createCommandStack();
  let value = 0;
  stack.exec({ do() { value = 5; }, undo() { value = 0; } });
  if (value !== 5) throw new Error('PRO2EDITOR command stack exec failed');
  stack.undo();
  if (value !== 0) throw new Error('PRO2EDITOR command stack undo failed');
  stack.redo();
  if (value !== 5) throw new Error('PRO2EDITOR command stack redo failed');
}

function testMeasure() {
  const geom = new THREE.BoxGeometry(3, 5, 7);
  const mesh = new THREE.Mesh(geom, new THREE.MeshBasicMaterial());
  const stats = computeBoundingMeasurement(mesh);
  if (!approxEqual(stats.width, 3) || !approxEqual(stats.height, 5) || !approxEqual(stats.depth, 7)) {
    throw new Error(`PRO2EDITOR measure dimensions mismatch: ${stats.width}, ${stats.height}, ${stats.depth}`);
  }
  const expectedDiag = Math.sqrt(3*3 + 5*5 + 7*7);
  if (!approxEqual(stats.diagonal, expectedDiag)) {
    throw new Error(`PRO2EDITOR measure diagonal mismatch: ${stats.diagonal} vs ${expectedDiag}`);
  }
}

try {
  testDataStore();
  testCommandStack();
  testMeasure();
  console.log('Phase 3 smoke tests passed');
} catch (err) {
  console.error(err);
  process.exit(1);
}
