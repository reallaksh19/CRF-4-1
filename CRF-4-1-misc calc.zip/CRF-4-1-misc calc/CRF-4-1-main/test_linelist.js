import fs from 'fs';
import { getLinelistService, getLinelist } from './viewer/core/linelist-store.js';

const svc = getLinelistService();

// Mock CSV parse
const rows = [
    ["Line Number", "Liquid Density", "Gas Density", "Mixed Density", "Flow Velocity", "Liquid Velocity", "Gas Velocity"],
    ["1001-A", "1000", "1.2", "500", "2.0", "1.5", "15.0"]
];

svc.processRawData("test.csv", rows);

// Check if keys mapped correctly
const store = getLinelist();
console.log("Mapped LineRef:", store.smartMap.LineRef);
console.log("Mapped DensityLiquid:", store.smartMap.DensityLiquid);
console.log("Mapped VelocityGas:", store.smartMap.VelocityGas);

// Check lookup
const result = svc.getSmartAttributes("1001-A");
console.log("Found:", result.Found);
console.log("DensityLiquid value:", result.DensityLiquid);
console.log("VelocityGas value:", result.VelocityGas);
